#include "duckdb/main/extension.hpp"

namespace duckdb {

Extension::~Extension() {
}

} // namespace duckdb
