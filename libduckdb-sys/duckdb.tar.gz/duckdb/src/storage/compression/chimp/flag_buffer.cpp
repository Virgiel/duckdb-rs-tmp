#include "duckdb/storage/compression/chimp/algorithm/flag_buffer.hpp"

namespace duckdb {

constexpr uint8_t FlagBufferConstants::MASKS[];
constexpr uint8_t FlagBufferConstants::SHIFTS[];

} // namespace duckdb
