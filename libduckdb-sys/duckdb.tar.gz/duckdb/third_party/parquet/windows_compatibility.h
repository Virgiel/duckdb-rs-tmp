#pragma once

#ifdef _WIN32
#undef CREATE_NEW
#undef OPTIONAL
#undef Realloc
#undef min
#undef max
#endif