#include "src/core_functions/scalar/random/random.cpp"

#include "src/core_functions/scalar/random/setseed.cpp"

