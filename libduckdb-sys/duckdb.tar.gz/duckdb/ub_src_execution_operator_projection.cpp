#include "src/execution/operator/projection/physical_projection.cpp"

#include "src/execution/operator/projection/physical_tableinout_function.cpp"

#include "src/execution/operator/projection/physical_pivot.cpp"

#include "src/execution/operator/projection/physical_unnest.cpp"

