#include "src/function/scalar/struct/struct_extract.cpp"

